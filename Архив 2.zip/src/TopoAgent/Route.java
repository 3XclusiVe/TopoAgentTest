package TopoAgent;

/**
 * Сетевой маршрут
 */
public class Route {

    public Route() {

    }

    public String Destination;
    public String Gateway;
    public String GenMask;
    public long Flag;
    public long Metric;
    public long Reference;
    public String Interface;

}
