package TopoAgent;
import org.hyperic.sigar.SigarException;


public class Main {
    public static void main(String[] args) throws SigarException, InterruptedException {



    /**

        TopoAgent MonitoringAgent = new TopoAgent(10000);

        Thread.currentThread().sleep(10000);

        MonitoringAgent.setFixedPeriod(100);

        Thread.currentThread().sleep(10000);

        MonitoringAgent.setFixedPeriod(10);

        Thread.currentThread().sleep(1000);

            MonitoringAgent.stop();

      //  Thread.currentThread().sleep(10000);

        //MonitoringAgent.reset();
     **/

    }
}
