package TopoAgent;

/**
 * Сетевой интерфейс
 */
public class NetInterface {

    public NetInterface() {

    }

    public String Name;
    public String MacAdress;
    public String IPAdress;
    public String NetMask;
    public long Flag;
    public long MTU;
    public long Metrics;
    public String Broadcast;
    public String Destination;
    public String Description;
}
