package TopoAgent;

public interface Observer {
    void Update();
}
